create procedure sp_upgrade_firewall_rule()
  BEGIN  	IF NOT EXISTS (SELECT * FROM information_schema.COLUMNS WHERE COLUMN_NAME = 'rule_type' AND TABLE_NAME = '__firewall_rules__' AND TABLE_SCHEMA = 'mysql') 	THEN 		ALTER TABLE `mysql`.`__firewall_rules__` 		ADD COLUMN `rule_type` INT NOT NULL AFTER `end_ip_address`; 		FLUSH FIREWALL_RULES; 	END IF; END;

