create procedure sp_delete_firewall_rule(IN firewallName varchar(128))
  BEGIN 	DELETE FROM `mysql`.`__firewall_rules__` 	WHERE `name`=firewallName; 	SELECT ROW_COUNT(); 	FLUSH FIREWALL_RULES; END;

